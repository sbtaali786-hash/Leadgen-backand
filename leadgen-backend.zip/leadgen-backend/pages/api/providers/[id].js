// PATCH /api/providers/:id -> approve/reject/suspend (admin only)

import { query } from "../../../lib/db";
import { requireAdmin } from "../../../lib/auth";

export default async function handler(req, res) {
  const { id } = req.query;

  if (req.method === "PATCH") {
    const admin = requireAdmin(req, res);
    if (!admin) return;

    const { status } = req.body || {};
    if (!["pending", "approved", "rejected", "suspended"].includes(status)) {
      return res.status(400).json({ error: "Invalid status" });
    }

    const { rows } = await query(
      `UPDATE providers SET status = $1, approved_at = CASE WHEN $1 = 'approved' THEN now() ELSE approved_at END
       WHERE id = $2 RETURNING *`,
      [status, id]
    );
    if (!rows.length) return res.status(404).json({ error: "Provider not found" });
    return res.status(200).json(rows[0]);
  }

  res.setHeader("Allow", ["PATCH"]);
  return res.status(405).end();
}
