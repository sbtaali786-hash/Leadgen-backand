// GET  /api/providers -> list providers (?status=pending for admin queue)
// POST /api/providers -> register a new provider (public — from signup form)

import { query } from "../../../lib/db";

export default async function handler(req, res) {
  if (req.method === "GET") {
    const { status, phone } = req.query;
    const conditions = [];
    const params = [];
    if (status) { params.push(status); conditions.push(`status = $${params.length}`); }
    if (phone) { params.push(phone); conditions.push(`phone = $${params.length}`); }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const { rows } = await query(
      `SELECT * FROM providers ${where} ORDER BY created_at DESC LIMIT 200`,
      params
    );
    return res.status(200).json(rows);
  }

  if (req.method === "POST") {
    const { companyName, contactName, email, phone, whatsappNumber, categoryIds, serviceAreaIds } = req.body || {};
    if (!companyName || !email || !phone) {
      return res.status(400).json({ error: "companyName, email, and phone are required" });
    }

    const { rows } = await query(
      `INSERT INTO providers (company_name, contact_name, email, phone, whatsapp_number)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [companyName, contactName || null, email, phone, whatsappNumber || phone]
    );
    const provider = rows[0];

    for (const catId of categoryIds || []) {
      await query(`INSERT INTO provider_categories (provider_id, category_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, [provider.id, catId]);
    }
    for (const areaId of serviceAreaIds || []) {
      await query(`INSERT INTO provider_service_areas (provider_id, service_area_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, [provider.id, areaId]);
    }

    return res.status(201).json(provider);
  }

  res.setHeader("Allow", ["GET", "POST"]);
  return res.status(405).end();
}
